function eliteIds = elitism(fitness)
    % return the best individual
    [val eliteIds] = min(fitness);
end