function eliteIds = elitism(fitness)
    % return the best individual
    [val eliteIds] = max(fitness);
%    [val Ids] = sort(fitness);
%    Ids = fliplr(Ids);
%    eliteIds = Ids(1:6);
end